package com.example.trabalho_pratica

import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var audioHelper: AudioHelper
    private lateinit var tts: TextToSpeech
    private lateinit var tvStatus: TextView
    private val TAG = "MainActivity"

    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            super.onAudioDevicesAdded(addedDevices)
            if (audioHelper.audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)) {
                Log.d(TAG, "Bluetooth headset connected")
                speak("Bluetooth headset connected")
                updateStatus("Bluetooth Connected")
            }
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            super.onAudioDevicesRemoved(removedDevices)
            if (!audioHelper.audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)) {
                Log.d(TAG, "Bluetooth headset disconnected")
                speak("Bluetooth headset disconnected")
                updateStatus("Bluetooth Disconnected")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        audioHelper = AudioHelper(this)
        tts = TextToSpeech(this, this)
        tvStatus = findViewById(R.id.tvStatus)

        val isSpeakerAvailable = audioHelper.audioOutputAvailable(AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)
        if (isSpeakerAvailable) {
            tvStatus.text = "Speaker Available"
        } else {
            tvStatus.text = "Speaker Not Available"
        }

        val btnOpenBluetooth = findViewById<Button>(R.id.btnOpenBluetooth)
        btnOpenBluetooth.setOnClickListener {
            openBluetoothSettings()
        }

        val btnSpeak = findViewById<Button>(R.id.btnSpeak)
        btnSpeak.setOnClickListener {
            speak("Welcome to Doma assistance. How can I help you?")
        }

        audioHelper.getAudioManager().registerAudioDeviceCallback(audioDeviceCallback, null)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e(TAG, "Language not supported")
            } else {
                speak("Application started")
            }
        } else {
            Log.e(TAG, "TTS Initialization failed")
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun updateStatus(status: String) {
        runOnUiThread {
            tvStatus.text = status
        }
    }

    private fun openBluetoothSettings() {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("EXTRA_CONNECTION_ONLY", true)
            putExtra("EXTRA_CLOSE_ON_CONNECT", true)
            putExtra("android.bluetooth.devicepicker.extra.FILTER_TYPE", 1)
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        audioHelper.getAudioManager().unregisterAudioDeviceCallback(audioDeviceCallback)
        super.onDestroy()
    }
}
